#!/usr/bin/env python
# encoding: utf-8
"""
copyright (c) 2016  Earth Advantage.
All rights reserved
"""

# Local Imports
from scourgify.normalize import (
    get_geocoder_normalized_addr,
    normalize_address_record,
)
